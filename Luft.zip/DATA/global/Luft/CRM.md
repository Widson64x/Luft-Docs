
O CRM (Customer Relationship Management) é a área responsável pelo relacionamento com o cliente dentro do processo logístico.

Principais funções:
- Registro e acompanhamento de solicitações de clientes.
- Gerenciamento do histórico de atendimento.
- Interface entre clientes, operação e demais áreas da empresa.

O uso do [[CRM]] garante maior rastreabilidade e melhora o nível de serviço ao cliente.
