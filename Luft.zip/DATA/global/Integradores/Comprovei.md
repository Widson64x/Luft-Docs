## Visão Geral

A Comprovei é uma empresa parceira da Luft Logistics. realiza o controle de entregas da empresa.

## Contato e Suporte

* **E-mail para Abertura de Chamados:** Para abrir um chamado via e-mail, o endereço é [atendimento@comprovei-ct6.movidesk.com](atendimento@comprovei-ct6.movidesk.com).
* **Contato Alternativo 1:** Melize Mota - `9 5300-2055`
* **Contato Alternativo 2 :** Kelly - `(35) 9717-4050`