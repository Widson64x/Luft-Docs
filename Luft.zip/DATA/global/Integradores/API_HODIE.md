## Finalidade
API para inserir canhoto de notas fiscais.

## Informações Técnicas
* **Documentação:** [https://gatewayhodie.runteccorp.com/gatewayqa/hodiegatewayapiisapi.dll/docs/#/Invoices/Nota%20Fiscal.Controller.%20TNFeController_InserirCanhotoNotas%20Fiscais](https://gatewayhodie.runteccorp.com/gatewayqa/hodiegatewayapiisapi.dll/docs/#/Invoices/Nota%20Fiscal.Controller.%20TNFeController_InserirCanhotoNotas%20Fiscais)
* **Usuário:** `gtw_luft`
* **Senha:** `#Lg4$5U*22%80%F*07$%T#`
* **Caminho do Processo:** `\\172.16.200.80\c$\Program Files (x86)\Services\Service EnvioEDIClientesAPI`