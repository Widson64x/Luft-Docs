## Finalidade
API de Carga para inserir embarque e ocorrência.

## Informações Técnicas
* **Documentação:** [https://utilities.confirmafacil.com.br/business/swagger-ui/index.html#/API%20de%20Carga/inserirEmbarqueOcorrencia](https://utilities.confirmafacil.com.br/business/swagger-ui/index.html#/API%20de%20Carga/inserirEmbarqueOcorrencia)
* **Usuário:** `celula.edi@luftlogistics.com`
* **Senha:** `Luft@@123`
* **Caminho do Processo:** `\\172.16.200.80\c$\Program Files (x86)\Services\Service EnvioEDIClientesAPI`