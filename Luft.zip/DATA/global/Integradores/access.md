## Visão Geral

- Parceira responsável por digitalizar, **DACTES**, **DANFES**, **MINUTAS**.

## Contatos

- **EMAIL SUPORTE**: [atendimento@accessbrasil.movidesk.com](atendimento@accessbrasil.movidesk.com)

Telefone:

- **ITUPEVA**: `(11) 50380977`
- **SÃO PAULO**: `(11)50433476`

SITE DE ACESSO:

- plataforma de acesso: [allstore2.accesscorp.com.br/#/login](allstore2.accesscorp.com.br/#/login)