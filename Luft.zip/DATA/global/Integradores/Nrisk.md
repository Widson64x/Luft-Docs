## Descrição
Razão Social: N Risk Gerenciamento de Risco e Logística.

## Contato
* **Nome:** Ricardo A. Ferreira
* **Departamento:** Tecnologia da Informação
* **E-mail Geral:** [informatica@nrisklog.com.br](informatica@nrisklog.com.br)
* **Telefone:** `(11) 2424-1350`
* **Endereço:** Av. Cauaxi, 350, 17º andar, Alphaville - Barueri/SP, CEP 06454-020