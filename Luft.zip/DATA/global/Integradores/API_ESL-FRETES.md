## Finalidade
Envio de CT-es via API.

## Informações Técnicas
* **Documentação:** [https://documenter.getpostman.com/view/20571375/2s9YXk2fj5#c5ecd338-3d54-437b-8fab-af7f85df8de8](https://documenter.getpostman.com/view/20571375/2s9YXk2fj5#c5ecd338-3d54-437b-8fab-af7f85df8de8)
* **Endpoint:** `https://lufthealthcare.eslcloud.com.br/api/freight/batches`
* **Token:** `sQ9T_W9DrA1fzwJsf5gsykmssXQsxCpCA96FaxJFu66u6k9yztymvQ`
* **Caminho do Processo:** `\\172.16.200.82\c$\Program Files (x86)\Services\Servico Envio CTes ESL`
* **Observação:** O processo foi conduzido por Marcelo.