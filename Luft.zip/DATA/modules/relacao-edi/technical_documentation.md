# Controle de EDIs de Transporte

Este documento centraliza o status e a configuração dos arquivos de Intercâmbio Eletrônico de Dados (EDI) trocados com clientes e parceiros. O objetivo é fornecer uma visão geral e acesso rápido aos detalhes de cada cliente.

## Relação de Clientes

A tabela abaixo resume os clientes, separados por **Nome Fantasia**, que possuem configurações de EDI. Clique no nome do cliente para acessar a página com todas as suas especificações.

| Cliente (Nome Fantasia) | Principais EDIs Ativos | Status Geral | Detalhes |
| :--- | :---: | :---: | :--- |
| ABL | `CONEMB`, `DOCCOB` | Ativo | [[EDI-ABL]] |
| ANOVIS | `OCOREN`, `DOCCOB` | Ativo | [[EDI-ANOVIS]] |
| ASPEN PHARMA | `CONEMB`, `DOCCOB`, `OCOREN` | Ativo | [[EDI-ASPEN-PHARMA]] |
| ASPEN PHARMA DISTRIBUIDORA | `CONEMB`, `DOCCOB` | Ativo | [[EDI-ASPEN-PHARMA-DISTRIBUIDORA]] |
| ASTELLAS DEP ITAPEVI | `CONEMB`, `DOCCOB`, `OCOREN` | Ativo | [[EDI-ASTELLAS-DEP-ITAPEVI]] |
| ASTRAZENECA | `CONEMB`, `DOCCOB`, `OCOREN` | Ativo | [[EDI-ASTRAZENECA]] |
| BIOMEDICAL - ITAJAÍ | `OCOREN` | Ativo | [[EDI-BIOMEDICAL-ITAJAI]] |
| BLANVER SC | `CONEMB`, `DOCCOB`, `OCOREN` | Ativo | [[EDI-BLANVER-SC]] |
| CELLERA | `OCOREN`, `DOCCOB` | Ativo | [[EDI-CELLERA]] |
| CELLERA CONSUMO | `OCOREN`, `DOCCOB` | Ativo | [[EDI-CELLERA-CONSUMO]] |
| EXPANSCIENCE | `CONEMB`, `OCOREN` | Ativo | [[EDI-EXPANSCIENCE]] |
| F&F | `OCOREN`, `DOCCOB` | Ativo | [[EDI-F&F]] |
| GALDERMA | `CONEMB`, `OCOREN` | Ativo | [[EDI-GALDERMA]] |
| GSK - (ITAPEVI) | `CONEMB`, `OCOREN` | Ativo | [[EDI-GSK-ITAPEVI]] |
| GUERBET RJ | `DOCCOB` | Ativo | [[EDI-GUERBET-RJ]] |
| HALEON - FILIAL0002 | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-HALEON-FILIAL0002]] |
| HALEON - FILIAL0006 | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-HALEON-FILIAL0006]] |
| ISDIN ITAJAÍ | `CONEMB`, `DOCCOB` | Ativo | [[EDI-ISDIN-ITAJAI]] |
| ISDIN ITAPEVI | `CONEMB`, `DOCCOB` | Ativo | [[EDI-ISDIN-ITAPEVI]] |
| LIBBS | `CONEMB`, `DOCCOB` | Ativo | [[EDI-LIBBS]] |
| LUNDBECK | `CONEMB`, `DOCCOB` | Ativo | [[EDI-LUNDBECK]] |
| MARJAN | `CONEMB` | Ativo | [[EDI-MARJAN]] |
| MEAD JOHNSON | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-MEAD-JOHNSON]] |
| MERCK-GO | `CONEMB`, `DOCCOB` | Ativo | [[EDI-MERCK-GO]] |
| MOKSHA8-SC | `CONEMB`, `OCOREN` | Ativo | [[EDI-MOKSHA8-SC]] |
| NAOS BRASIL | `CONEMB` | Ativo | [[EDI-NAOS-BRASIL]] |
| OPELLA SP | `CONEMB`, `DOCCOB` | Ativo | [[EDI-OPELLA-SP]] |
| ORGANON GO | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-ORGANON-GO]] |
| PHARLAB | `OCOREN` | Ativo | [[EDI-PHARLAB]] |
| PRODUTOS ROCHE | `OCOREN`, `DOCCOB` | Ativo | [[EDI-PRODUTOS-ROCHE]] |
| RANBAXY | `OCOREN` | Ativo | [[EDI-RANBAXY]] |
| RECKITT EMBU | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-RECKITT-EMBU]] |
| SANOFI GENMED | `CONEMB`, `DOCCOB` | Ativo | [[EDI-SANOFI-GENMED]] |
| SEMINA | `OCOREN` | Ativo | [[EDI-SEMINA]] |
| SUN FARMACEUTICA | `OCOREN` | Ativo | [[EDI-SUN-FARMACEUTICA]] |
| TAKEDA - SC | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-TAKEDA-SC]] |
| TAKEDA - SP | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-TAKEDA-SP]] |
| TAKEDA PHARMA | `CONEMB`, `OCOREN`, `DOCCOB` | Ativo | [[EDI-TAKEDA-PHARMA]] |
| UNIAO QUIMICA PO | `OCOREN`, `DOCCOB` | Ativo | [[EDI-UNIAO-QUIMICA-PO]] |

### Anexos

*  [SQLQuery3 - Relação de EDIs Ativos.sql](/download?token=__TOKEN_PLACEHOLDER__&download=SQLQuery3_-_Relacao_de_EDIs_Ativos.sql&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzIjoid2lkc29uLmFyYXVqbyIsImUiOjE3NTM5MDg0MzV9.-wgsJe_yOhJ8IIqTIzNRVc-ABHoO4V0XwwQM4XY_3qU)

* [DOCCOB-50.pdf](/download?token=__TOKEN_PLACEHOLDER__&download=DOCCOB-50.pdf&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzIjoid2lkc29uLmFyYXVqbyIsImUiOjE3NTQwMDQzMzJ9.6T8W3n9N4UJIceiBE7hLMvuWfLiEGMhWDlleq6kIgj0)

*  [CONEMB-50.pdf](/download?token=__TOKEN_PLACEHOLDER__&download=CONEMB-50.pdf&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzIjoid2lkc29uLmFyYXVqbyIsImUiOjE3NTQwMDQzMzJ9.6T8W3n9N4UJIceiBE7hLMvuWfLiEGMhWDlleq6kIgj0)

*  [OCOREN-50 - Atualizado .pdf](/download?token=__TOKEN_PLACEHOLDER__&download=OCOREN-50_-_Atualizado_.pdf&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzIjoid2lkc29uLmFyYXVqbyIsImUiOjE3NTQwMDQzMzJ9.6T8W3n9N4UJIceiBE7hLMvuWfLiEGMhWDlleq6kIgj0)