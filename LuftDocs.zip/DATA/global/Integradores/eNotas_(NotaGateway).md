## Finalidade
Emissão de NFS-e, antigo eNotas.

## Acessos e Suporte
* **Portal de Configuração (Dados, Fiscal, Certificado):** [https://app.enotasgw.com.br/login?returnUrl=%2F](https://app.enotasgw.com.br/login?returnUrl=%2F)
* **Portal para Abertura de Chamados:** [https://atendimento.notagateway.com.br/Account/Login?ReturnUrl=%2fHome](https://atendimento.notagateway.com.br/Account/Login?ReturnUrl=%2fHome)
* **Documentação da API:** [https://app.enotasgw.com.br/docs#/](https://app.enotasgw.com.br/docs#/)

## Credenciais
* **Usuário:** `cleyton.tome@luftlogistics.com`
* **Senha:** `Luft@1234`

## Informações Técnicas
* **Caminho do Processo:** `\\172.16.200.82\c$\Program Files (x86)\Services\Servico_Emissao_NFSe_eNotas`