## Finalidade
Suporte para GNRE.

## Acessos e Suporte
* **Portal de Atendimento (Chamados):** [https://atendimento.tecnospeed.com.br/hc/pt-br](https://atendimento.tecnospeed.com.br/hc/pt-br)
* **Portal da Conta:** [https://conta.tecnospeed.com.br/](https://conta.tecnospeed.com.br/)

## Credenciais
* **Usuário (Atendimento e Conta):** `francisco.miranda@luftlogistics.com`
* **Senha (Atendimento e Conta):** `luft@123`

## Informações Técnicas
* **Caminho do Processo:** `\\172.16.200.208\c$\Program Files (x86)\SKAC\ServicoGNRE`