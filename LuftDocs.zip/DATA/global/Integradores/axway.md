##  Finalidade

- B2BI, recebe interfaces e envia. 

## Portal de Chamados

- **LINK**: [https://172.16.200.50:6443/ui/](https://172.16.200.50:6443/ui/)
- **EMAIL**: [support@axway.com](support@axway.com)
- **Suporte**: `11 3704 9913`