## Finalidade

- Gestão de fretes de clientes.

## Contatos

- E-mail: suporte.entregou@esales.com.br
- Telefone: 51 3325.8100

## Usuário de Acesso **SFTP**

- HostName = 200.9.174.224
- Usuário = LUFT
- -Senha = pm8Cw3Rm

## Clientes

- ISDIN
- Pharlab
- Takeda
- União Quimíca