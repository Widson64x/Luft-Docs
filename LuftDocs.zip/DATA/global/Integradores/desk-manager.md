## Finalidade

- Portal de chamados **TI**.

**Telefone**: `(11) 2146-0000`

**Email**: [deskmanager@meajuda.ai](deskmanager@meajuda.ai)

## Portal de Chamados

- **Link**: [https://luftlogistics.desk.ms/?LoginPortal](https://luftlogistics.desk.ms/?LoginPortal)