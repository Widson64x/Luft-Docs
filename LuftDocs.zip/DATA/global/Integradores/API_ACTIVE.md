## Finalidade
Integração de ocorrências.

## Informações Técnicas
* **Documentação:** [https://app.swaggerhub.com/apis-docs/ActiveCorp/Active_OnSupply/4.0.5](https://app.swaggerhub.com/apis-docs/ActiveCorp/Active_OnSupply/4.0.5)
* **Endpoint:** `http://srvinterno.activecorp.com.br:28080/API/IntegracaoPublica/Ocorrencia`
* **Token:** `FC939359-F573-4B38-AFCF-33D0E1A21B5F`
* **Caminho do Processo:** `\\172.16.200.80\c$\Program Files (x86)\Services\Service EnvioEDIClientesAPI`