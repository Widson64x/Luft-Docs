
### **Azul Cargo**

**Informações de Acesso:**

* **URL do Portal:** `https://edi.onlineapp.com.br/` 
* **Caminho de Acesso:** Após acessar o link, selecionar "Portal EDI" e, em seguida, "Acessar AD Azul".
* **Usuário:** `cristiano.silva@luftlogistics.com` 
* **Senha Padrão (primeiro acesso):** `Azul@azulcargo@2025` 

**Observações Adicionais:**

* O e-mail para o qual os arquivos XML de AWB devem ser enviados prioritariamente é `edi.aereo@luftlogistics.com`.
