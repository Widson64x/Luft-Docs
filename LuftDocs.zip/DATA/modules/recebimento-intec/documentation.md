## Visão Geral do Processo

Este documento estabelece o fluxo de trabalho completo para a recepção de mercadorias, unificando as etapas desde a chegada do veículo até a finalização sistêmica da carga. O processo de recebimento é dividido em três modalidades principais 'Transferência, Coleta e Cliente Entrega:

* **Transferências de Filiais:** Cargas recebidas de outras unidades da empresa.
* **Coletas:** Cargas coletadas diretamente em clientes.
* **Cliente Entrega:** Modalidade específica para quando o próprio cliente realiza a entrega da carga na unidade.

A organização do departamento classifica os processos em três estágios: carregado, descarregado e finalizado.

## Etapa 1: Chegada do Veículo e Registro Inicial (Manual)

A operação começa com a recepção física do veículo e a criação de um registro de controle manual.

* **Recepção e Identificação:**
    * O motorista encosta o veículo na doca designada ou no pátio.
    * Ele apresenta as notas fiscais e, em alguns casos, uma Ordem de Serviço (OS) para facilitar a identificação.
* **Caderno de Controle:**
    * Um caderno físico é utilizado para o primeiro registro.
    * O motorista deve preencher as seguintes informações:
        * Nome do motorista
        * Placa do veículo (a do "cavalo" em caso de carreta)
        * Origem da carga (ex: Sanofi, filial de Goiânia)
        * Número da Doca ou Pátio (PT)
        * Data e hora da chegada
        * Assinatura
* **Finalidade do Caderno:**
    * Este registro é crucial para vincular os lotes de notas aos motoristas corretos, especialmente em coletas sem OS. A falta deste controle pode gerar grande confusão no momento de processar as notas.

## Etapa 2: Registro Sistêmico (Tela "Recebimento Diversos")

Após o controle manual, as informações são inseridas no sistema.

* **Acesso ao Sistema:**
    * O processo é executado na tela de "Recebimento Diversos", dentro da seção de "Operação".
* **Regra dos 11 Minutos:**
    * **É obrigatório retroceder o horário em 11 minutos** ao registrar a chegada.
    * O sistema não permite o registro com o horário atual.
* **Preenchimento de Dados:**
    * **Placa:** Informar a placa do veículo.
    * **Material, Espécie e Modal:** Definir o tipo de material (ex: Laboratório), a espécie (ex: Caixas) e o modal (normalmente "Rodoviário").
* **Processamento de Notas Fiscais:**
    * O operador deve escanear ("bipar") todas as notas fiscais da carga. No caso de transferências, as notas já estão pré-manifestadas.
    * É altamente recomendável realizar uma segunda contagem das notas para evitar esquecimentos.
    * Após a seleção, é necessário clicar em **"Processar XML"** para validação.

## Etapa 3: Geração do Documento de Conferência

Com a carga registrada, o próximo passo é consolidar as informações em um documento formal.

* **Geração do Documento de Conferência:**
    * O **Documento de Conferência** que permite a conferência da carga.
    * Ele contém:
        * Números das notas fiscais
        * Dados do cliente e do destinatário
        * Peso e volumetria (quantidade de caixas)
        * **Pallet:** A informação de pallet só aparece para o processo de transferência.

![Documento de Conferência](/data/img/recebimento-intec/img1.jpeg)

## Etapa 4: Conferência Física da Carga

A verificação física da mercadoria é uma etapa crítica e **inteiramente manual**.

* **Procedimento de Conferência:**
    * O conferente utiliza o Documento de Conferência e as notas fiscais para verificar a quantidade de volumes descrita e realiza a contagem física da carga.
    * A conferência é feita pallet a pallet.
* **Tratamento de Divergências:**
    * Se houver divergência (falta ou sobra), o conferente anota o ocorrido no campo de observações do Documento de Conferência.
    * Posteriormente, essa informação é lançada no sistema para gerar a Ocorrência **33**.

## Etapa 5: Finalização Sistêmica (Confirmação do Veículo)

Esta é a etapa final de extrema importância para a cadeia operacional.

* **Obrigatoriedade da Confirmação:**
    * Após o recebimento, é **mandatório** que o veículo seja "confirmado" no sistema na tela de ‘Consulta Recebimento Transporte’.
* **Consequências da Não Confirmação:**
    * Se um veículo não for confirmado, ele fica "bloqueado" sistemicamente.
    * **Bloqueio de Notas:** As notas fiscais ficam presas e não podem ser trabalhadas por outras áreas.
    * **Bloqueio do Veículo:** A equipe de Frota fica impossibilitada de gerar uma nova OS para o veículo.
    * **Impacto na Emissão:** O setor de Emissão também fica impedido de processar os documentos.

## Processos Detalhados de Montagem Etiqueta

Esta seção detalha os processos de apoio que conectam o recebimento à expedição.

* **Montagem de Etiqueta de Pallet:**
    * **Finalidade:** Agrupar um conjunto de volumes ou notas em pallets, gerando uma etiqueta única de identificação no sistema.
    * **Responsabilidade:** Embora seja uma tarefa dos conferentes, muitas vezes é executada pelo administrativo do recebimento. Esta prática é considerada "arriscada", pois qualquer erro fica registrado no login de quem executou a tarefa.

## Telas Luft Informa

### Acessar a Seção de Operação

Para começar, localize e acesse a seção **Operação [14]** na árvore de módulos do sistema. Esta é a principal ferramenta utilizada pela equipe de recebimento.

![Acesso ao Seção de Operação](/data/img/recebimento-intec/img1.png)

---

### Iniciar o Processo em "Recebimento Diversos"

Dentro da seção de Operação, a primeira ação é definir o tipo de recebimento.

- **Ação:** Selecione a opção **Transporte**. O recebimento da INTEC é especificamente focado nesta modalidade.

![Tela de Recebimento Diversos](/data/img/recebimento-intec/img2.png)

---

### Preenchimento dos Dados da Chegada

Siga os passos abaixo para registrar as informações do veículo e da carga.

1.  **Doca:** Insira o número da doca onde o caminhão está estacionado.
    ![Seleção do Tipo Transporte](/data/img/recebimento-intec/img3.png)

2.  **Placa e Data/Hora:** Preencha a placa do veículo e a data e horário exatos da chegada na doca.
    > **Atenção:** Lembre-se de seguir a **"regra dos 11 minutos"** para o registro de horário.
    ![Campo Doca](/data/img/recebimento-intec/img4.png)

3.  **Seleção da Coleta:** Escolha a coleta correspondente que ainda não foi recebida.
    ![Campo Placa e Data/Hora](/data/img/recebimento-intec/img5.png)

---

### Recebimento e Processamento das Notas

Com todos os dados preenchidos, o último passo é registrar as notas fiscais.

1.  **Receber:** Clique no botão **"Receber"**.
    ![Botão Receber](/data/img/recebimento-intec/img6.png)
2.  **Bipar as Notas:** Realize a leitura (bip) dos códigos de barras das notas fiscais.
    - *Observação:* Para casos de **transferência**, as notas já devem aparecer na tela, pois são pré-manifestadas.
3.  **Processar XML:** Para finalizar, clique em **Processar XML**. O recebimento estará concluído.

![Processar XML](/data/img/recebimento-intec/img7.png)

### Tela de Consulta e confirmação de Recebimento

Confirmação Final do Recebimento

Após o processamento das notas (etapa anterior), o passo final é confirmar a conclusão da descarga e liberar o veículo.

- **Objetivo:** Esta tela é usada pelo Administrador (ADM) para confirmar que o caminhão foi 100% descarregado, a conferência física foi realizada e o veículo está liberado.
- **Diferença:** Enquanto a tela anterior registra a **chegada** do veículo na doca, esta confirma a **conclusão** de todo o processo de recebimento.

![Tela de Confirmação de Recebimento](/data/img/recebimento-intec/img8.png)

Com certeza. Segue o documento ajustado com os espaçamentos solicitados na seção das telas, conforme o modelo.

-----

## Visão Geral do Processo de Passagem de Carga

Este documento estabelece o fluxo de trabalho para a **Passagem de Carga** da INTEC. O processo inicia-se após o recebimento físico e documental da carga vinda da FARMA, que encerra sua responsabilidade com a entrega de um documento de "check-out".

O fluxo da INTEC é projetado para garantir a conferência, consolidação, planejamento e expedição correta das mercadorias, sendo dividido em quatro etapas principais:

1.  **Conferência de Recebimento:** Validação inicial de todos os volumes recebidos.
2.  **Montagem de Etiqueta de Pallet:** Consolidação de volumes/notas em unidades logísticas (pallets).
3.  **Planejamento de Embarque:** Alocação estratégica das cargas nos veículos de transporte.
4.  **Conferência de Embarque:** Verificação final no momento do carregamento do veículo.

## Etapa 1: Recebimento e Conferência Inicial

A operação começa com a conferência de todos os volumes que a FARMA passou para a responsabilidade da INTEC.

  * **Validação por Volume:**
      * O operador utiliza um coletor de dados para escanear ("bipar") individualmente cada caixa.
      * O sistema valida a sequência (ex: 1 de 20, 2 de 20) e aponta especificamente qualquer volume faltante. O processo não avança até que a divergência seja resolvida.

## Etapa 2: Montagem de Etiqueta de Pallet

Após a conferência, as cargas podem ser agrupadas para otimizar o manuseio e o transporte.

  * **Finalidade:** Agrupar um conjunto de volumes ou notas em pallets, gerando uma etiqueta única de identificação para facilitar o rastreamento e a movimentação.
  * **Processo de Consolidação:**
      * O operador seleciona no sistema as notas fiscais que serão agrupadas em um mesmo pallet.
      * O sistema gera uma nova etiqueta de pallet, que consolida todas as informações das notas selecionadas.
  * **Impressão e Afixação:**
      * A nova etiqueta é impressa. Uma cópia é afixada no pallet de forma visível e outra é anexada à documentação da carga.

## Etapa 3: Planejamento de Embarque

Esta é a fase estratégica onde se decide como a carga será transportada.

  * **Criação de Veículos Virtuais:**
      * A equipe de planejamento monta "viagens" ou "veículos virtuais" no sistema, definindo as rotas e destinos.
  * **Alocação de Carga:**
      * Com base em critérios como prazo de entrega (TT), cliente, valor e tipo de carga (perecível), o planejador aloca as etiquetas de pallet geradas na etapa anterior aos veículos virtuais.
      * Esta etapa é crucial para garantir o cumprimento de prazos e a otimização da capacidade dos veículos.

## Etapa 4: Conferência de Embarque e Expedição

A verificação final antes da saída do veículo.

  * **Procedimento:**
      * No momento de carregar o caminhão, o operador utiliza o coletor para escanear a etiqueta de cada pallet que está sendo embarcado.
  * **Validação Sistêmica:**
      * O sistema confirma se o pallet lido pertence de fato àquela viagem planejada.
      * Isso previne erros de expedição, garantindo que apenas a carga correta seja enviada para o destino certo.

## Telas Luft Informa

### Acessar a Seção de Operação

Para começar, localize e acesse a seção **Operação [14]** na árvore de módulos do sistema. Aqui se encontram todas as ferramentas para a passagem, montagem e expedição da carga.

![Acesso ao Seção de Operação](/data/img/recebimento-intec/img1.png)

-----

### Iniciar o Processo em "Recebimento Diversos"

Dentro da seção de Operação, a primeira ação é definir o tipo de recebimento.

- **Ação:** Selecione a opção **Armazém**. 

![Tela de Recebimento Diversos](/data/img/recebimento-intec/img2.png)

-----

Você está absolutamente correto. Peço sinceras desculpas pela confusão e pela interpretação incorreta das imagens. Agradeço a sua paciência e a correção.

Analisando novamente com base nos nomes corretos das abas que você forneceu, aqui está a descrição precisa da tela **"Recebimento Farma x Intec"** e suas funcionalidades.

### **Tela de Recebimento Farma x Intec**

Esta tela é a ferramenta central para a gestão do recebimento de cargas da Farma, dividida em cinco abas funcionais, cada uma com um propósito específico no processo.

#### **Aba 1: Dados do Recebimento**

Esta é a principal tela de operação para a entrada de mercadorias.

  * **Função:** É aqui que o operador realiza o registro inicial da carga no sistema.
  * **Operação:** O processo é feito através da leitura do código de barras ("bipagem") da `ChaveNFe`, Após a leitura de todos os itens, a sessão é finalizada com o botão `Encerrar`.

![/data/img/recebimento-intec/img10.png](/data/img/recebimento-intec/img10.png)

-----

#### **Aba 2: Resumo dos Recebimentos**

Esta aba oferece uma visão geral e consolidada dos processos em andamento.

  * **Função:** Funciona como um painel de controle para monitorar o status de todos os pallets que foram recebidos.
  * **Visibilidade:** A grade exibe informações cruciais como `Nº Pallet`, data e hora do recebimento, o `Status` atual (ex: "Aguardando Armazenagem"), o `Recebedor` e o `Conferente`.
  
 ![/data/img/recebimento-intec/img11.png](/data/img/recebimento-intec/img11.png)
-----

#### **Aba 3: Estornar notas já recebidas**

Esta é uma ferramenta para correção de erros no processo de recebimento.

  * **Função:** Permite cancelar ou reverter o recebimento de uma nota ou pallet que foi registrado incorretamente.
  * **Operação:** O usuário utiliza os campos `Chave NFe` ou `Pallet` para localizar o item a ser revertido e clica no botão `Estornar Recebimento`.
  
![/data/img/recebimento-intec/img12.png](/data/img/recebimento-intec/img12.png)
-----

#### **Aba 4: Retorno de Paletes Armazém**

Esta aba gerencia a etapa final do ciclo de vida dos pallets dentro do armazém.

  * **Função:** Controlar o fluxo de retorno dos pallets após a finalização da conferência.
  * **Visibilidade:** A grade exibe os pallets cujo status já é "Conferência Finalizada", indicando que estão prontos para serem movimentados ou retornados.

![/data/img/recebimento-intec/img13.png](/data/img/recebimento-intec/img13.png)