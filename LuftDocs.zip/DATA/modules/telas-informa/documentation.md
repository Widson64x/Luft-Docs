# **Filtros do Luft Informa**

## **1. Visão Geral**

A tela de **Relatórios Gerais** é o hub central do sistema **Luft Informa** para a extração e análise de dados. Ela permite que os usuários localizem, configurem, gerem e manipulem relatórios operacionais de forma dinâmica e intuitiva.

O principal objetivo desta tela é fornecer flexibilidade para que cada usuário possa customizar a visualização dos dados de acordo com sua necessidade, além de exportar as informações em diferentes formatos.

## **Video Tutorial**

<video width="640" height="360" controls>
  <source src="https://bpms.luftlogistics.com/LuftDocs/123_FERRAMENTAS%20DO%20LUFTINFORMA.mp4" type="video/mp4">
  Seu navegador não suporta a tag de vídeo.
</video>

## **2. Fluxo de Utilização**

O processo para gerar e analisar um relatório segue um fluxo simples de 4 passos:

1.  **Encontrar o Relatório:** Localizar o relatório desejado usando os filtros.
2.  **Definir Parâmetros:** Configurar as variáveis do relatório (ex: período, cliente).
3.  **Gerar e Analisar:** Executar o relatório e utilizar as ferramentas da grade para analisar os dados.
4.  **Exportar ou Enviar:** Salvar os dados em um arquivo ou enviá-los por e-mail.

## **3. Funcionalidades Detalhadas**

### **3.1. Encontrando um Relatório**

A tela oferece duas maneiras principais para localizar um relatório:

* **Filtrar por Nome:**
    * **Como usar:** Digite uma parte do nome do relatório no campo de filtro `Filtrar Menu`.
    * **Exemplo:** Digitando `Entrega`, o sistema listará todos os relatórios que contenham "Entrega" no nome.

* **Filtrar por Número:**
    * **Como usar:** Selecione a opção `Número` no filtro e digite o código do relatório.
    * **Exemplo:** Para o relatório "Monitoramento - Planilha SAC", basta digitar o número `1300`.

### **3.2. Gerando o Relatório**

Após selecionar o relatório, a tela exibirá os campos de parâmetros necessários.

1.  **Preencha os Parâmetros:** Informe os dados solicitados, como `Período`, `Cliente`, `UF Destino`, etc.
2.  **Clique em Gerar:** O sistema processará a solicitação e exibirá os resultados na grade de dados na parte inferior da tela.

### **3.3. Ferramentas Avançadas da Grade de Resultados**

Uma vez que os dados são exibidos, você pode usar uma série de ferramentas poderosas para analisá-los diretamente na tela. Para acessar a maioria delas, **clique com o botão direito do mouse no cabeçalho da coluna** que deseja manipular.

* #### **Ordenação**
    * **O que faz:** Organiza todas as linhas do relatório com base nos valores de uma coluna.
    * **Como usar:** Clique com o botão direito na coluna e selecione `Ordenar Ascendente` (A-Z, 0-9) ou `Ordenar Descendente` (Z-A, 9-0).

* #### **Agrupamento**
    * **O que faz:** Cria uma visualização hierárquica, agrupando linhas que possuem o mesmo valor em uma determinada coluna.
    * **Como usar (Método 1 - Arrastar):** Clique e segure o cabeçalho da coluna (ex: `Remetente`) e arraste-o para a barra cinza que diz *"Arraste um cabeçalho de coluna aqui para agrupar por esta coluna"*.
    * **Como usar (Método 2 - Menu):** Clique com o botão direito na coluna e selecione `Agrupar por este Campo`.

* #### **Gerenciamento de Colunas**
    * `Remover Esta Coluna`: Oculta a coluna selecionada da grade.
    * `Lista de Colunas`: Abre uma janela que permite marcar/desmarcar quais colunas devem ser exibidas. Ideal para trazer de volta uma coluna removida.
    * `Melhor Ajuste` / `Melhor Ajuste (Todas as Colunas)`: Redimensiona automaticamente a largura da(s) coluna(s) para que todo o seu conteúdo fique visível, sem cortes.

* #### **Fórmulas e Sumarização no Rodapé**
    * **O que faz:** Realiza cálculos rápidos sobre uma coluna numérica e exibe o resultado no rodapé da grade.
    * **Como usar:**
        1.  Clique com o botão direito no espaço do rodapé abaixo da coluna desejada (ex: coluna "Volumes").
        2.  Selecione a fórmula desejada:
            * `Soma`: Calcula o total dos valores.
            * `Média`: Calcula a média.
            * `Contagem`: Conta o número de registros.
            * `Mínimo`: Mostra o menor valor.
            * `Máximo`: Mostra o maior valor.
        3. É possível adicionar múltiplos resumos na mesma coluna (ex: uma Soma e uma Média).

## **4. Exportação e Envio**

Após customizar o relatório, você pode exportar os dados usando os botões localizados acima da grade:

* **`Email`**: Abre uma janela para enviar o relatório como anexo diretamente pelo sistema.
* **`Excel`**: Exporta a grade de dados para um arquivo `.xlsx`. **Importante:** Todos os agrupamentos, ordenações e sumarizações feitos na tela serão mantidos no arquivo do Excel.
* **`TXT`**: Exporta os dados para um arquivo de texto simples, separado por delimitadores.