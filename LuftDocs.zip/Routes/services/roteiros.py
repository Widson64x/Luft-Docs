# routes/roteiros.py

from flask import Blueprint, request, jsonify, session # Importar 'session'
from models import db, Roteiro, Modulo, RoteiroAuditLog
from Utils.auth.auth_utils import login_required

# Nome do nosso novo Blueprint
roteiros_bp = Blueprint('roteiros', __name__, url_prefix='/api/roteiros')

# --- ROTA PARA CRIAR UM NOVO ROTEIRO ---
@roteiros_bp.route('/', methods=['POST'])
@login_required
def criar_roteiro():
    """ Cria um novo roteiro e registra o log de auditoria. """
    user_perms = session.get('permissions', {})
    if not user_perms.get('can_edit_scripts', False):
        return jsonify({'status': 'error', 'message': 'Acesso negado.'}), 403

    data = request.get_json()
    if not data or not data.get('titulo') or not data.get('conteudo'):
        return jsonify({'status': 'error', 'message': 'Título e conteúdo são obrigatórios.'}), 400

    novo_roteiro = Roteiro(
        titulo=data['titulo'],
        tipo=data.get('tipo', 'link'),
        conteudo=data['conteudo'],
        icone=data.get('icone'),
        ordem=data.get('ordem', 0)
    )
    db.session.add(novo_roteiro)

    # --- CRIAÇÃO DO LOG DE AUDITORIA ---
    log_entry = RoteiroAuditLog(
        roteiro=novo_roteiro,
        user_id=session.get('user_id'),
        user_name=session.get('user_name'),
        action='CREATE'
    )
    db.session.add(log_entry)
    # --- FIM DA CRIAÇÃO DO LOG ---
    
    db.session.commit()

    return jsonify({
        'status': 'success', 'message': 'Roteiro criado com sucesso!',
        'roteiro': {'id': novo_roteiro.id, 'titulo': novo_roteiro.titulo, 'tipo': novo_roteiro.tipo}
    }), 201

# --- ROTA PARA VINCULAR UM ROTEIRO A MÓDULOS ---
@roteiros_bp.route('/vincular', methods=['POST'])
@login_required
def vincular_roteiro_a_modulo():
    """
    Vincula um roteiro existente a uma lista de IDs de módulos.
    """
    # --- PROTEÇÃO DE ROTA ---
    user_perms = session.get('permissions', {})
    if not user_perms.get('can_edit_scripts', False):
        return jsonify({'status': 'error', 'message': 'Acesso negado. Você não tem permissão para vincular roteiros.'}), 403
    # --- FIM DA PROTEÇÃO ---

    data = request.get_json()
    roteiro_id = data.get('roteiro_id')
    modulo_ids = data.get('modulo_ids')

    if not roteiro_id or not modulo_ids:
        return jsonify({'status': 'error', 'message': 'ID do roteiro e lista de módulos são obrigatórios.'}), 400

    roteiro = Roteiro.query.get(roteiro_id)
    if not roteiro:
        return jsonify({'status': 'error', 'message': 'Roteiro não encontrado.'}), 404

    modulos = Modulo.query.filter(Modulo.id.in_(modulo_ids)).all()
    
    for modulo in modulos:
        if modulo not in roteiro.modulos:
            roteiro.modulos.append(modulo)

    db.session.commit()

    return jsonify({
        'status': 'success',
        'message': f'Roteiro "{roteiro.titulo}" vinculado a {len(modulos)} módulo(s).'
    }), 200


# --- ROTA PARA OBTER DADOS DE UM ROTEIRO (PARA EDIÇÃO) ---
@roteiros_bp.route('/<int:roteiro_id>', methods=['GET'])
@login_required
def get_roteiro(roteiro_id):
    """ 
    Retorna os detalhes de um roteiro específico. 
    Esta rota não precisa de proteção, pois é apenas para visualização.
    """
    roteiro = Roteiro.query.get_or_404(roteiro_id)
    
    modulos_vinculados = [modulo.id for modulo in roteiro.modulos]

    return jsonify({
        'id': roteiro.id,
        'titulo': roteiro.titulo,
        'descricao': roteiro.descricao,
        'tipo': roteiro.tipo,
        'conteudo': roteiro.conteudo,
        'icone': roteiro.icone,
        'ordem': roteiro.ordem,
        'modulos_vinculados': modulos_vinculados
    })

# --- ROTA PARA ATUALIZAR UM ROTEIRO ---
@roteiros_bp.route('/<int:roteiro_id>', methods=['PUT'])
@login_required
def atualizar_roteiro(roteiro_id):
    """ Atualiza um roteiro existente e registra o log de auditoria. """
    user_perms = session.get('permissions', {})
    if not user_perms.get('can_edit_scripts', False):
        return jsonify({'status': 'error', 'message': 'Acesso negado.'}), 403

    roteiro = Roteiro.query.get_or_404(roteiro_id)
    data = request.get_json()

    roteiro.titulo = data.get('titulo', roteiro.titulo)
    roteiro.descricao = data.get('descricao', roteiro.descricao)
    roteiro.tipo = data.get('tipo', roteiro.tipo)
    roteiro.conteudo = data.get('conteudo', roteiro.conteudo)
    roteiro.icone = data.get('icone', roteiro.icone)
    roteiro.ordem = data.get('ordem', roteiro.ordem)

    # --- CRIAÇÃO DO LOG DE AUDITORIA ---
    log_entry = RoteiroAuditLog(
        roteiro_id=roteiro.id,
        user_id=session.get('user_id'),
        user_name=session.get('user_name'),
        action='UPDATE'
    )
    db.session.add(log_entry)
    # --- FIM DA CRIAÇÃO DO LOG ---

    db.session.commit()
    
    return jsonify({'status': 'success', 'message': 'Roteiro atualizado com sucesso!'})

# --- ROTA PARA EXCLUIR UM ROTEIRO ---
# --- ROTA PARA EXCLUIR UM ROTEIRO (VERSÃO CORRIGIDA) ---
@roteiros_bp.route('/<int:roteiro_id>', methods=['DELETE'])
@login_required
def excluir_roteiro(roteiro_id):
    """ 
    Exclui um roteiro do banco de dados e registra a ação no log de auditoria. 
    """
    # --- Proteção de Rota (Mantida) ---
    user_perms = session.get('permissions', {})
    if not user_perms.get('can_edit_scripts', False):
        return jsonify({'status': 'error', 'message': 'Acesso negado. Você não tem permissão para excluir roteiros.'}), 403

    roteiro = Roteiro.query.get_or_404(roteiro_id)
    
    # --- CRIAÇÃO DO LOG DE AUDITORIA ANTES DE DELETAR ---
    log_entry = RoteiroAuditLog(
        roteiro_id=roteiro.id,  # Usamos o ID diretamente
        user_id=session.get('user_id'),
        user_name=session.get('user_name'),
        action='DELETE'
    )
    db.session.add(log_entry)
    # --- FIM DA CRIAÇÃO DO LOG ---

    # Agora, deletamos o roteiro. O cascade do SQLAlchemy irá remover os logs
    # de CREATE e UPDATE antigos, mas o nosso novo log de DELETE persistirá.
    db.session.delete(roteiro)
    db.session.commit()

    return jsonify({'status': 'success', 'message': 'Roteiro excluído com sucesso!'})